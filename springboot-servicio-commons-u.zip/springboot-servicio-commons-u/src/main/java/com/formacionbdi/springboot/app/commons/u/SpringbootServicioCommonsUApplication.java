package com.formacionbdi.springboot.app.commons.u;

import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootServicioCommonsUApplication {


}
