INSERT INTO usuarios (username,password,enabled,nombre,apellido,email) VALUES('elmer','$2a$10$LvoDH4nJD/FyJv5w1DX6VOn8EIwThvZX3Pxkp7LLabd3IG0qJ1wbm',1,'Elmer','Garcia','elmerjg08@gmail.com');
INSERT INTO usuarios (username,password,enabled,nombre,apellido,email) VALUES('admin','$2a$10$LvoDH4nJD/FyJv5w1DX6VOn8EIwThvZX3Pxkp7LLabd3IG0qJ1wbm',1,'Jose','Gonzalez','josejg08@gmail.com');
INSERT INTO usuarios (username,password,enabled,nombre,apellido,email) VALUES('john','$2a$10$LvoDH4nJD/FyJv5w1DX6VOn8EIwThvZX3Pxkp7LLabd3IG0qJ1wbm',1,'John','Hernandez','johnjg08@gmail.com');

INSERT INTO roles (nombre) VALUES('ROLE_USER');
INSERT INTO roles (nombre) VALUES('ROLE_ADMIN');

INSERT INTO usuarios_to_roles (usuario_id, role_id) VALUES(1,1);
INSERT INTO usuarios_to_roles (usuario_id, role_id) VALUES(2,2);
INSERT INTO usuarios_to_roles (usuario_id, role_id) VALUES(2,1);
INSERT INTO usuarios_to_roles (usuario_id, role_id) VALUES(3,1);