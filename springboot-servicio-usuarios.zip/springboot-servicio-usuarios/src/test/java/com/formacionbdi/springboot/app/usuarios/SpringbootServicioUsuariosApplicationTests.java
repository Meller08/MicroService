package com.formacionbdi.springboot.app.usuarios;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootServicioUsuariosApplicationTests {

	@Test
	void contextLoads() {
	}

}
