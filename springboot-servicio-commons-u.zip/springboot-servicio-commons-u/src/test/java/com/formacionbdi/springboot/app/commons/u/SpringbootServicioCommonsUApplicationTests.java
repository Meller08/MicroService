package com.formacionbdi.springboot.app.commons.u;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootServicioCommonsUApplicationTests {

	@Test
	void contextLoads() {
	}

}
