package com.formacionbdi.springboot.app.oauth;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootServicioOauthApplicationTests {

	@Test
	void contextLoads() {
	}

}
